export const HUBTEL_ORDER_URL = 'https://hubtel.com';

export const openHubtelOrder = () => {
  showToast('Opening Hubtel ordering page...');
  window.open(HUBTEL_ORDER_URL, '_blank', 'noopener,noreferrer');
};

export const showToast = (message: string) => {
  const toast = document.createElement('div');
  toast.className = 'fixed bottom-4 right-4 bg-gray-900 text-white px-6 py-3 rounded-lg shadow-lg z-50 animate-slide-up';
  toast.textContent = message;
  document.body.appendChild(toast);

  setTimeout(() => {
    toast.classList.add('opacity-0', 'transition-opacity', 'duration-300');
    setTimeout(() => {
      document.body.removeChild(toast);
    }, 300);
  }, 2000);
};
