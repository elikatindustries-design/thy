export interface MenuItem {
  id: string;
  name: string;
  category: 'Rice' | 'Yam & Chips' | 'Extras';
  price: number;
  description: string;
  image?: string;
}

export interface GalleryImage {
  id: string;
  url: string;
  alt: string;
}
