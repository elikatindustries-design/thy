import { Phone, ShoppingBag } from 'lucide-react';
import { openHubtelOrder } from '../utils/hubtel';

export default function Hero() {
  return (
    <section className="relative bg-gradient-to-br from-orange-500 via-red-500 to-orange-600 min-h-screen flex items-center">
      <div className="absolute inset-0 bg-black/30"></div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 sm:py-32">
        <div className="text-center text-white">
          <div className="inline-block mb-6 px-4 py-2 bg-white/20 backdrop-blur-sm rounded-full">
            <span className="text-sm font-medium">Established: 10 June 2023</span>
          </div>

          <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold mb-6 leading-tight">
            Nessa's Place
          </h1>

          <p className="text-xl sm:text-2xl md:text-3xl font-semibold mb-8 text-orange-100">
            A taste you'll remember
          </p>

          <p className="text-lg sm:text-xl mb-12 max-w-2xl mx-auto text-gray-100">
            Experience authentic Ghanaian flavors with our signature Jollof rice,
            perfectly seasoned fried rice, and crispy yam chips. Every meal crafted
            with love and the finest ingredients.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <button
              onClick={openHubtelOrder}
              className="w-full sm:w-auto flex items-center justify-center space-x-3 px-8 py-4 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-all transform hover:scale-105 shadow-lg text-lg font-bold"
            >
              <ShoppingBag size={24} />
              <span>Order Now on Hubtel</span>
            </button>

            <a
              href="tel:0266108738"
              className="w-full sm:w-auto flex items-center justify-center space-x-3 px-8 py-4 bg-white text-orange-600 rounded-lg hover:bg-orange-50 transition-all transform hover:scale-105 shadow-lg text-lg font-bold"
            >
              <Phone size={24} />
              <span>Call: 0266108738</span>
            </a>
          </div>
        </div>
      </div>

      <div className="absolute bottom-0 left-0 right-0">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 120">
          <path fill="#ffffff" fillOpacity="1" d="M0,64L48,69.3C96,75,192,85,288,80C384,75,480,53,576,48C672,43,768,53,864,58.7C960,64,1056,64,1152,58.7C1248,53,1344,43,1392,37.3L1440,32L1440,120L1392,120C1344,120,1248,120,1152,120C1056,120,960,120,864,120C768,120,672,120,576,120C480,120,384,120,288,120C192,120,96,120,48,120L0,120Z"></path>
        </svg>
      </div>
    </section>
  );
}
