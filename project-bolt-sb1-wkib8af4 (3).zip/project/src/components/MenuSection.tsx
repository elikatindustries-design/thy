import { useState } from 'react';
import { ShoppingBag, Filter } from 'lucide-react';
import { menuItems } from '../data/menuData';
import { openHubtelOrder } from '../utils/hubtel';

export default function MenuSection() {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');

  const categories = ['All', 'Rice', 'Yam & Chips', 'Extras'];

  const filteredItems =
    selectedCategory === 'All'
      ? menuItems
      : menuItems.filter((item) => item.category === selectedCategory);

  return (
    <section id="menu" className="py-16 sm:py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">
            Our Full Menu
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Browse our complete selection of delicious meals. All prices in GHS.
          </p>
        </div>

        <div className="flex items-center justify-center mb-8 flex-wrap gap-3">
          <div className="flex items-center space-x-2 text-gray-600">
            <Filter size={20} />
            <span className="font-medium">Filter:</span>
          </div>
          {categories.map((category) => (
            <button
              key={category}
              onClick={() => setSelectedCategory(category)}
              className={`px-4 sm:px-6 py-2 rounded-full font-medium transition-all ${
                selectedCategory === category
                  ? 'bg-orange-600 text-white shadow-md'
                  : 'bg-white text-gray-700 hover:bg-orange-50 border border-gray-200'
              }`}
            >
              {category}
            </button>
          ))}
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8 mb-12">
          {filteredItems.map((item) => (
            <div
              key={item.id}
              className="bg-white rounded-2xl shadow-md overflow-hidden hover:shadow-xl transition-all transform hover:-translate-y-1 border border-gray-100"
            >
              <div className="h-48 overflow-hidden">
  <img
    src={item.image}
    alt={item.name}
    className="w-full h-full object-cover"
  />
</div>
                <div className="absolute top-4 right-4 bg-white px-3 py-1 rounded-full">
                  <span className="text-xs font-semibold text-gray-600">
                    {item.category}
                  </span>
                </div>
              <div className="p-6">
                <h3 className="text-xl font-bold text-gray-900 mb-2">
                  {item.name}
                </h3>
                <p className="text-gray-600 mb-4 text-sm leading-relaxed">
                  {item.description}
                </p>
                <div className="flex items-center justify-between">
                  <span className="text-2xl font-bold text-orange-600">
                    {item.price}gh
                  </span>
                  <button
                    onClick={openHubtelOrder}
                    className="flex items-center space-x-2 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors text-sm font-medium"
                    aria-label={`Order ${item.name} on Hubtel`}
                  >
                    <ShoppingBag size={16} />
                    <span>Order</span>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="bg-white rounded-2xl shadow-lg p-8 text-center border border-gray-100">
          <h3 className="text-2xl font-bold text-gray-900 mb-4">
            Ready to Order?
          </h3>
          <p className="text-gray-600 mb-6">
            Scan the QR code or click below to order on Hubtel
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-6">
            <div className="w-48 h-48 bg-gradient-to-br from-orange-100 to-red-100 rounded-xl flex items-center justify-center border-2 border-orange-200">
              <span className="text-gray-400 text-sm">QR Code Placeholder</span>
            </div>
            <button
              onClick={openHubtelOrder}
              className="px-8 py-4 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors text-lg font-bold flex items-center space-x-3 shadow-lg"
            >
              <ShoppingBag size={24} />
              <span>Order on Hubtel</span>
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
