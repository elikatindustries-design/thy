import { useState } from 'react';
import { X } from 'lucide-react';

export default function GallerySection() {
  const [selectedImage, setSelectedImage] = useState<number | null>(null);

  // Put your images inside:  /src/assets/
  const galleryImages = [
    {
      id: 1,
      url: "src/assets/IMG-20251122-WA0137.jpg",
      alt: "Dish 1",
    },
    {
      id: 2,
      url: "src/assets/IMG-20251122-WA0148.jpg",
      alt: "Dish 2",
    },
    {
      id: 3,
      url: "src/assets/IMG-20251122-WA0150.jpg",
      alt: "Dish 3",
    },
    {
      id: 4,
      url: "src/assets/IMG-20251122-WA0149.jpg",
      alt: "Dish 4",
    },
  ];

  const openLightbox = (index: number) => setSelectedImage(index);
  const closeLightbox = () => setSelectedImage(null);

  const navigateImage = (direction: 'prev' | 'next') => {
    if (selectedImage === null) return;

    if (direction === 'prev') {
      setSelectedImage(
        selectedImage === 0 ? galleryImages.length - 1 : selectedImage - 1
      );
    } else {
      setSelectedImage(
        selectedImage === galleryImages.length - 1 ? 0 : selectedImage + 1
      );
    }
  };

  return (
    <section id="gallery" className="py-16 sm:py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">
            Gallery
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Take a visual journey through our delicious offerings
          </p>
        </div>

        {/* GALLERY GRID */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
          {galleryImages.map((image, index) => (
            <button
              key={image.id}
              onClick={() => openLightbox(index)}
              className="aspect-square bg-gray-200 rounded-lg overflow-hidden hover:shadow-xl transition-all transform hover:scale-105 cursor-pointer"
              aria-label={`View ${image.alt}`}
            >
            <img
  src={image.url}
  alt={image.alt}
  className="aspect-square bg-gray-200 rounded-lg overflow-hidden hover:shadow-xl transition-shadow cursor-pointer"
  onClick={() => openLightbox(index)}
  aria-label={`View ${image.alt}`}
/>
            </button>
          ))}
        </div>
      </div>

      {/* LIGHTBOX */}
      {selectedImage !== null && (
        <div
          className="fixed inset-0 bg-black/90 z-50 flex items-center justify-center p-4"
          onClick={closeLightbox}
        >
          <button
            onClick={closeLightbox}
            className="absolute top-4 right-4 text-white hover:text-orange-500 transition-colors"
            aria-label="Close lightbox"
          >
            <X size={32} />
          </button>

          <button
            onClick={(e) => {
              e.stopPropagation();
              navigateImage('prev');
            }}
            className="absolute left-4 text-white hover:text-orange-500 transition-colors text-4xl font-bold"
            aria-label="Previous image"
          >
            ‹
          </button>

          <img
            src={galleryImages[selectedImage].url}
            alt={galleryImages[selectedImage].alt}
            className="max-w-4xl w-full rounded-lg object-contain"
            onClick={(e) => e.stopPropagation()}
          />

          <button
            onClick={(e) => {
              e.stopPropagation();
              navigateImage('next');
            }}
            className="absolute right-4 text-white hover:text-orange-500 transition-colors text-4xl font-bold"
            aria-label="Next image"
          >
            ›
          </button>
        </div>
      )}
    </section>
  );
}