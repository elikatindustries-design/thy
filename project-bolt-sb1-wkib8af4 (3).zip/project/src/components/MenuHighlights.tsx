import { ShoppingBag } from 'lucide-react';
import { menuItems } from '../data/menuData';
import { openHubtelOrder } from '../utils/hubtel';

export default function MenuHighlights() {
  const highlights = menuItems.slice(0, 6);

  return (
    <section className="py-16 sm:py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">
            Our Popular Dishes
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Discover our most loved meals, prepared fresh daily with authentic
            flavors and premium ingredients
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          {highlights.map((item) => (
            <div
              key={item.id}
              className="bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow border border-gray-100"
            >
             <div className="h-48">
  <img
    src={item.image}
    alt={item.name}
    className="w-full h-full object-cover"
  />
</div> 
              <div className="p-6">
                <h3 className="text-xl font-bold text-gray-900 mb-2">
                  {item.name}
                </h3>
                <p className="text-gray-600 mb-4 text-sm">{item.description}</p>
                <div className="flex items-center justify-between">
                  <span className="text-2xl font-bold text-orange-600">
                    {item.price}gh
                  </span>
                  <button
                    onClick={openHubtelOrder}
                    className="flex items-center space-x-2 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors text-sm font-medium"
                  >
                    <ShoppingBag size={16} />
                    <span>Order</span>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center mt-12">
          <button
            onClick={() => {
              const menuSection = document.getElementById('menu');
              menuSection?.scrollIntoView({ behavior: 'smooth' });
            }}
            className="px-8 py-3 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition-colors text-lg font-medium"
          >
            View Full Menu
          </button>
        </div>
      </div>
    </section>
  );
}
