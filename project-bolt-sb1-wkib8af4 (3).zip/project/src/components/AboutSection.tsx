import { Heart, Users, Award, Clock } from 'lucide-react';

export default function AboutSection() {
  return (
    <section id="about" className="py-16 sm:py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">
            About Nessa's Place
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            A taste you'll remember
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-16">
          <div className="space-y-6">
            <div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4">Our Story</h3>
              <p className="text-gray-600 leading-relaxed">
                Since opening our doors on 10 June 2023, Nessa's Place has been
                committed to bringing you the most authentic and delicious Ghanaian
                cuisine. What started as a passion for sharing traditional flavors
                has grown into a beloved local restaurant where every dish tells a
                story.
              </p>
            </div>
            <div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4">Our Mission</h3>
              <p className="text-gray-600 leading-relaxed">
                We're dedicated to creating unforgettable dining experiences through
                authentic flavors, quality ingredients, and warm hospitality. Every
                meal we prepare is a celebration of Ghanaian culinary traditions,
                served with love and care. Our goal is simple: to give you a taste
                you'll remember.
              </p>
            </div>
          </div>

          <div className="h-96 bg-gradient-to-br from-orange-400 to-red-500 rounded-2xl shadow-xl"></div>
        </div>

        <div>
          <h3 className="text-2xl font-bold text-gray-900 mb-8 text-center">
            Our Core Values
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="bg-orange-50 rounded-xl p-6 text-center border border-orange-100">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-orange-600 rounded-full mb-4">
                <Heart className="text-white" size={28} />
              </div>
              <h4 className="text-xl font-bold text-gray-900 mb-2">
                Made with Love
              </h4>
              <p className="text-gray-600 text-sm">
                Every dish is prepared with care and passion for authentic flavors
              </p>
            </div>

            <div className="bg-red-50 rounded-xl p-6 text-center border border-red-100">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-red-600 rounded-full mb-4">
                <Award className="text-white" size={28} />
              </div>
              <h4 className="text-xl font-bold text-gray-900 mb-2">
                Quality First
              </h4>
              <p className="text-gray-600 text-sm">
                We use only the finest ingredients for the best taste
              </p>
            </div>

            <div className="bg-orange-50 rounded-xl p-6 text-center border border-orange-100">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-orange-600 rounded-full mb-4">
                <Users className="text-white" size={28} />
              </div>
              <h4 className="text-xl font-bold text-gray-900 mb-2">
                Community Focus
              </h4>
              <p className="text-gray-600 text-sm">
                Proud to serve our local community with warmth and friendship
              </p>
            </div>

            <div className="bg-red-50 rounded-xl p-6 text-center border border-red-100">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-red-600 rounded-full mb-4">
                <Clock className="text-white" size={28} />
              </div>
              <h4 className="text-xl font-bold text-gray-900 mb-2">
                Always Fresh
              </h4>
              <p className="text-gray-600 text-sm">
                Food prepared fresh daily to ensure maximum flavor and quality
              </p>
            </div>
          </div>
        </div>

        <div className="mt-16 bg-gradient-to-r from-orange-600 to-red-600 rounded-2xl p-8 sm:p-12 text-center text-white shadow-xl">
          <h3 className="text-2xl sm:text-3xl font-bold mb-4">
            Visit Us Today
          </h3>
          <p className="text-lg mb-6 text-orange-100">
            Experience the warmth and flavor that makes Nessa's Place special
          </p>
          <a
            href="tel:0266108738"
            className="inline-block px-8 py-3 bg-white text-orange-600 rounded-lg hover:bg-orange-50 transition-colors text-lg font-bold"
          >
            Call: 0266108738
          </a>
        </div>
      </div>
    </section>
  );
}
